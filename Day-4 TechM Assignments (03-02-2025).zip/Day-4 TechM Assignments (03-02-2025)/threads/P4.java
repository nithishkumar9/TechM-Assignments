package threads;

public class P4 {

}
